// pages/products/index.tsx

import React from 'react';
import { Layout } from './layout';

function ProductsPage() {
  return (
    <Layout>
      <p>This is the products page.</p>
    </Layout>
  );
}

export default ProductsPage;